<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MailController extends Controller
{
  
    // ---------------- ['For Send Mail'] -----------------

    public function sendMail(Request $request){ 
        try { 
            $mail = $request->email; 
            if (env('MAIL_FROM_ADDRESS') == 'local'){
                echo 'Local Enviroment';
            }
            $details = [
              'title' => 'Job Subject',
              'body' => "fullname = " .$request->first_name. ' '.$request->last_name." ,".
                        "Email = ".$request->email.", ".
                        "Contact = ".$request->phone_number.", ".
                        "Experience = ".$request->experience.", ".
                        "Current_Salary = ".$request->current_salary.", ".
                        "Expected_Salary = ".$request->expected_salary.", ".
                        "Resume_Name = ".$request->resume_name,
              'mail' => $request->email,
              'first_name' => $request->first_name  
            ];
              $data = \Mail::to($mail)->send(new \App\Mail\MyTestMail($details));
              $response = array('status' => true, 'message' => 'Send Mail Success');
              $seccess = json_encode($response);
              return $seccess;
        }catch ( Exception $e ) {
            return response()->json( 'false' );
        }
    }

}
