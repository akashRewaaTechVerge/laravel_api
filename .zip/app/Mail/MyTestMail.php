<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class MyTestMail extends Mailable
{
    use Queueable, SerializesModels;

   public $details;
  
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($details)
    {
        $this->details = $details;
    }
  
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
         foreach($this as $value){
            $email = $value['mail'];
            $firstName = $value['first_name'];
           
            return $this 
            ->from($address = $email, $name = $firstName)
            ->subject('Job Subject')
                    ->view('emails.myTestMail');
         }
        // return $this 
        // ->from($address = 'noreply@domain.com', $name = 'Sender name')
        // ->subject('Job Subject')
        //             ->view('emails.myTestMail');
    }
}
